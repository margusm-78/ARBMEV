import 'dotenv/config';
import { ethers } from 'ethers';

const anvil = new ethers.JsonRpcProvider(process.env.ANVIL_URL || 'http://127.0.0.1:8545', { name: 'arbitrum', chainId: Number(process.env.ANVIL_CHAIN_ID || 42161) });

const USDC = process.env.TOKEN_USDC!;
const WETH = process.env.TOKEN_WETH!;
const ROUTER = process.env.UNISWAP_V3_ROUTER!;

const erc20Abi = [
  'function balanceOf(address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
  'function allowance(address,address) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function transfer(address,uint256) returns (bool)',
];

async function main() {
  const [sys] = await anvil.listAccounts();
  const signer = await anvil.getSigner(sys);
  const target = new ethers.Wallet(process.env.PRIVATE_KEY!, anvil);
  console.log('Anvil sys:', sys, ' Target:', await target.getAddress());

  // Give the target some ETH
  await anvil.send('anvil_setBalance', [await target.getAddress(), '0x56BC75E2D63100000']); // 100 ETH

  // Impersonate a USDC rich account to fund the target
  const usdcWhale = '0x0A59649758aa4d66E25f08Dd01271e891fe52199'; // Example whale, replace if needed
  await anvil.send('anvil_impersonateAccount', [usdcWhale]);
  const whaleSigner = await anvil.getSigner(usdcWhale);

  const usdc = new ethers.Contract(USDC, erc20Abi, whaleSigner);
  const decimals: number = await usdc.decimals();
  const amount = ethers.parseUnits('10000', decimals);
  console.log('Transferring', amount.toString(), 'USDC to target...');
  await usdc.transfer(await target.getAddress(), amount);
  await anvil.send('anvil_stopImpersonatingAccount', [usdcWhale]);

  // Approve router
  const targetUsdc = usdc.connect(target);
  const allowance: bigint = await targetUsdc.allowance(await target.getAddress(), ROUTER);
  if (allowance < amount) {
    console.log('Approving router for USDC...');
    await targetUsdc.approve(ROUTER, ethers.MaxUint256);
  }
  console.log('Done.');
}

main().catch((e) => { console.error(e); process.exit(1); });
