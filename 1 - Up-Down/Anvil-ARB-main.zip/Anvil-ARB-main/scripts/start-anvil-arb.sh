#!/usr/bin/env bash
set -euo pipefail

# Usage: ARB_RPC_URL=... ./scripts/start-anvil-arb.sh [BLOCK]
FORK_URL="${ANVIL_FORK_URL:-${ARB_RPC_URL:-}}"
BLOCK="${1:-${ANVIL_FORK_BLOCK:-}}"
CHAIN_ID="${ANVIL_CHAIN_ID:-42161}"

if [ -z "${FORK_URL}" ]; then
  echo "Set ARB_RPC_URL or ANVIL_FORK_URL first"; exit 1
fi

args=(--fork-url "${FORK_URL}" --chain-id "${CHAIN_ID}" --base-fee 0 --steps-tracing)
if [ -n "${BLOCK}" ]; then
  args+=(--fork-block-number "${BLOCK}")
fi

echo ">>> Starting anvil fork for Arbitrum (chain_id=${CHAIN_ID})"
echo "    URL: ${FORK_URL}  block: ${BLOCK:-latest}"
exec anvil "${args[@]}"
