import 'dotenv/config';
import { ethers } from 'ethers';

export function makeProvider(): ethers.Provider {
  const local = process.env.ANVIL_URL;
  if (local) {
    return new ethers.JsonRpcProvider(local, { name: 'arbitrum', chainId: Number(process.env.ANVIL_CHAIN_ID || 42161) });
  }
  // fallback to main RPCs
  const url = process.env.ARB_RPC_URL || process.env.ARB_RPC_URL_BACKUP;
  if (!url) throw new Error('Set ARB_RPC_URL or ANVIL_URL');
  return new ethers.JsonRpcProvider(url, { name: 'arbitrum', chainId: 42161 });
}
