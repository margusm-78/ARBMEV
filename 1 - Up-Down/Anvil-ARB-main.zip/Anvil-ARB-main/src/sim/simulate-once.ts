import 'dotenv/config';
import { ethers } from 'ethers';
import { makeProvider } from '../utils/provider.js';
import { quoteEthToUsdc } from './price.js';

async function simulateOnce() {
  const provider = makeProvider() as ethers.JsonRpcProvider;
  const q = await quoteEthToUsdc(provider, ethers.parseEther(process.env.PROBE_NOTIONAL_A || '0.1'));
  console.log(`[SIM] WETH→USDC best fee ${q.fee} out ≈ ${q.amountOutFormatted} USDC`);
}

simulateOnce().catch((e)=>{ console.error(e); process.exit(1); });
