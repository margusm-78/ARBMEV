import { ethers } from 'ethers';

const QuoterV2Abi = [
  'function quoteExactInputSingle((address tokenIn,address tokenOut,uint24 fee,uint256 amountIn,uint160 sqrtPriceLimitX96)) view returns (uint256 amountOut, uint160 sqrtPriceX96After, uint32 initializedTicksCrossed, uint256 gasEstimate)',
] as const;

export async function quoteEthToUsdc(provider: ethers.JsonRpcProvider, amountWei: bigint) {
  const weth = process.env.TOKEN_WETH!;
  const usdc = process.env.TOKEN_USDC!;
  const fees = [500, 3000, 10000];
  const quoter = new ethers.Contract(process.env.UNISWAP_V3_QUOTER_V2!, QuoterV2Abi, provider);

  let best: { fee:number, amountOut: bigint } | null = null;
  for (const fee of fees) {
    const params = { tokenIn: weth, tokenOut: usdc, fee, amountIn: amountWei, sqrtPriceLimitX96: 0n };
    const [amountOut] = await quoter.quoteExactInputSingle(params);
    if (!best || amountOut > best.amountOut) best = { fee, amountOut };
  }
  const decimals = 6n;
  const formatted = Number(best!.amountOut) / (10 ** Number(decimals));
  return { fee: best!.fee, amountOut: best!.amountOut, amountOutFormatted: formatted.toFixed(2) };
}
