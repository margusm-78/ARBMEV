import 'dotenv/config';
import { setTimeout as sleep } from 'node:timers/promises';
import { ethers } from 'ethers';
import { makeProvider } from '../utils/provider.js';
import { quoteEthToUsdc } from './price.js';

async function loop() {
  const provider = makeProvider() as ethers.JsonRpcProvider;
  while (true) {
    try {
      const q = await quoteEthToUsdc(provider, ethers.parseEther(process.env.PROBE_NOTIONAL_A || '0.1'));
      console.log(`[SIM] fee ${q.fee} out ≈ ${q.amountOutFormatted} USDC`);
    } catch (e) {
      console.error('Sim error:', e);
    }
    await sleep(1500);
  }
}

loop().catch((e)=>{ console.error(e); process.exit(1); });
